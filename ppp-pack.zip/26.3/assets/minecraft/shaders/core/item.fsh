#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

// Matching locations from item.vsh
layout(location = 7) in vec4 lightColor;
layout(location = 8) in vec4 baseColor;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color, bool isEmissive) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    
    // Emissive states skip block/sky lightmap attenuation
    if (!isEmissive) {
        color *= lightMapColor;
    }

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);
    #ifdef ALPHA_CUTOUT
    if (texColor.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    vec4 color = texColor;
    int currentAlpha = int(round(texColor.a * 255.0));
    bool isEmissive = false;

    switch (currentAlpha) {
        case 254: 
            // Emissive: skips directional lighting and block lightmap
            color *= baseColor * ColorModulator; 
            isEmissive = true;
            break;
            
        case 200: 
        case 250:
        case 252: 
        case 253: 
        case 100: 
        case 50: 
            // Unshaded: reacts to block light, ignores directional shading
            color *= lightColor * ColorModulator; 
            color.rgb *= 0.9; 
            break;
            
        default: 
            // Blend between directional lighting and flat lighting
            color *= mix(vertexColor, lightColor, 0.2) * ColorModulator; 
            break;
    }

    if (color.a < 0.1) discard;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color, isEmissive);
    #endif
}